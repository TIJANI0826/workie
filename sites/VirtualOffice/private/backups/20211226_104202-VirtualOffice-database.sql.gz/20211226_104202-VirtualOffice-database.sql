-- MariaDB dump 10.17  Distrib 10.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: workie    Database: _e0658c8751ff3532
-- ------------------------------------------------------
-- Server version	10.4.13-MariaDB-1:10.4.13+maria~focal

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__Auth`
--

DROP TABLE IF EXISTS `__Auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__Auth` (
  `doctype` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fieldname` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`doctype`,`name`,`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__Auth`
--

LOCK TABLES `__Auth` WRITE;
/*!40000 ALTER TABLE `__Auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `__Auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__UserSettings`
--

DROP TABLE IF EXISTS `__UserSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__UserSettings` (
  `user` varchar(180) NOT NULL,
  `doctype` varchar(180) NOT NULL,
  `data` text DEFAULT NULL,
  UNIQUE KEY `user` (`user`,`doctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__UserSettings`
--

LOCK TABLES `__UserSettings` WRITE;
/*!40000 ALTER TABLE `__UserSettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `__UserSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__global_search`
--

DROP TABLE IF EXISTS `__global_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__global_search` (
  `doctype` varchar(100) DEFAULT NULL,
  `name` varchar(140) DEFAULT NULL,
  `title` varchar(140) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `route` varchar(140) DEFAULT NULL,
  `published` int(1) NOT NULL DEFAULT 0,
  UNIQUE KEY `doctype_name` (`doctype`,`name`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__global_search`
--

LOCK TABLES `__global_search` WRITE;
/*!40000 ALTER TABLE `__global_search` DISABLE KEYS */;
INSERT INTO `__global_search` VALUES ('DocType','DocField','DocField','Name : DocField',NULL,0),('DocType','DocPerm','DocPerm','Name : DocPerm',NULL,0),('DocType','DocType','DocType','Name : DocType',NULL,0),('DocType','DocType Action','DocType Action','Name : DocType Action',NULL,0),('DocType','DocType Link','DocType Link','Name : DocType Link',NULL,0),('DocType','Role','Role','Name : Role',NULL,0),('DocType','Has Role','Has Role','Name : Has Role',NULL,0),('DocType','User','User','Name : User',NULL,0),('DocType','Custom Field','Custom Field','Name : Custom Field',NULL,0),('DocType','Property Setter','Property Setter','Name : Property Setter',NULL,0),('DocType','Web Form','Web Form','Name : Web Form',NULL,0),('DocType','Web Template','Web Template','Name : Web Template',NULL,0),('DocType','Web Form Field','Web Form Field','Name : Web Form Field',NULL,0),('DocType','Portal Menu Item','Portal Menu Item','Name : Portal Menu Item',NULL,0),('DocType','Data Migration Mapping Detail','Data Migration Mapping Detail','Name : Data Migration Mapping Detail',NULL,0),('DocType','Data Migration Mapping','Data Migration Mapping','Name : Data Migration Mapping',NULL,0),('DocType','Data Migration Plan Mapping','Data Migration Plan Mapping','Name : Data Migration Plan Mapping',NULL,0),('DocType','Data Migration Plan','Data Migration Plan','Name : Data Migration Plan',NULL,0),('DocType','Number Card','Number Card','Name : Number Card',NULL,0),('DocType','Dashboard Chart','Dashboard Chart','Name : Dashboard Chart',NULL,0),('DocType','Dashboard','Dashboard','Name : Dashboard',NULL,0),('DocType','Onboarding Permission','Onboarding Permission','Name : Onboarding Permission',NULL,0),('DocType','Onboarding Step','Onboarding Step','Name : Onboarding Step',NULL,0),('DocType','Onboarding Step Map','Onboarding Step Map','Name : Onboarding Step Map',NULL,0),('DocType','Module Onboarding','Module Onboarding','Name : Module Onboarding',NULL,0),('DocType','Desk Card','Desk Card','Name : Desk Card',NULL,0),('DocType','Desk Chart','Desk Chart','Name : Desk Chart',NULL,0),('DocType','Desk Shortcut','Desk Shortcut','Name : Desk Shortcut',NULL,0),('DocType','Desk Page','Desk Page','Name : Desk Page',NULL,0),('DocType','Version','Version','Name : Version',NULL,0),('DocType','Role Permission for Page and Report','Role Permission for Page and Report','Name : Role Permission for Page and Report',NULL,0),('DocType','Installed Applications','Installed Applications','Name : Installed Applications',NULL,0),('DocType','Custom DocPerm','Custom DocPerm','Name : Custom DocPerm',NULL,0),('DocType','Error Log','Error Log','Name : Error Log',NULL,0),('DocType','DocShare','DocShare','Name : DocShare',NULL,0),('DocType','Page','Page','Name : Page',NULL,0),('DocType','Deleted Document','Deleted Document','Name : Deleted Document',NULL,0),('DocType','Domain Settings','Domain Settings','Name : Domain Settings',NULL,0),('DocType','Access Log','Access Log','Name : Access Log',NULL,0),('DocType','Scheduled Job Type','Scheduled Job Type','Name : Scheduled Job Type',NULL,0),('DocType','Patch Log','Patch Log','Name : Patch Log',NULL,0),('DocType','Activity Log','Activity Log','Name : Activity Log',NULL,0),('DocType','Data Import Beta','Data Import Beta','Name : Data Import Beta',NULL,0),('DocType','Payment Gateway','Payment Gateway','Name : Payment Gateway',NULL,0),('DocType','Communication Link','Communication Link','Name : Communication Link',NULL,0),('DocType','Has Domain','Has Domain','Name : Has Domain',NULL,0),('DocType','Session Default Settings','Session Default Settings','Name : Session Default Settings',NULL,0),('DocType','SMS Settings','SMS Settings','Name : SMS Settings',NULL,0),('DocType','Error Snapshot','Error Snapshot','Name : Error Snapshot',NULL,0),('DocType','Report','Report','Name : Report',NULL,0),('DocType','Communication','Communication','Name : Communication',NULL,0),('DocType','Language','Language','Name : Language',NULL,0),('DocType','System Settings','System Settings','Name : System Settings',NULL,0),('DocType','User Email','User Email','Name : User Email',NULL,0),('Module Def','Core','Core','Name : Core',NULL,0),('DocType','Module Def','Module Def','Name : Module Def',NULL,0),('DocType','Scheduled Job Log','Scheduled Job Log','Name : Scheduled Job Log',NULL,0),('DocType','Comment','Comment','Name : Comment',NULL,0),('DocType','View Log','View Log','Name : View Log',NULL,0),('DocType','SMS Parameter','SMS Parameter','Name : SMS Parameter',NULL,0),('DocType','Video','Video','Name : Video',NULL,0),('DocType','Data Import','Data Import','Name : Data Import',NULL,0),('DocType','Success Action','Success Action','Name : Success Action',NULL,0),('DocType','Data Export','Data Export','Name : Data Export',NULL,0),('DocType','User Social Login','User Social Login','Name : User Social Login',NULL,0),('DocType','Translation','Translation','Name : Translation',NULL,0),('DocType','Server Script','Server Script','Name : Server Script',NULL,0),('DocType','Transaction Log','Transaction Log','Name : Transaction Log',NULL,0),('DocType','Block Module','Block Module','Name : Block Module',NULL,0),('DocType','Role Profile','Role Profile','Name : Role Profile',NULL,0),('DocType','DefaultValue','DefaultValue','Name : DefaultValue',NULL,0),('DocType','User Permission','User Permission','Name : User Permission',NULL,0),('DocType','Dynamic Link','Dynamic Link','Name : Dynamic Link',NULL,0),('DocType','Installed Application','Installed Application','Name : Installed Application',NULL,0),('DocType','Domain','Domain','Name : Domain',NULL,0),('DocType','Custom Role','Custom Role','Name : Custom Role',NULL,0),('DocType','Session Default','Session Default','Name : Session Default',NULL,0),('DocType','File','File','Name : File',NULL,0),('DocType','Prepared Report','Prepared Report','Name : Prepared Report',NULL,0),('Report','Document Share Report','Document Share Report','Name : Document Share Report',NULL,0),('Report','Permitted Documents For User','Permitted Documents For User','Name : Permitted Documents For User',NULL,0),('Report','Transaction Log Report','Transaction Log Report','Name : Transaction Log Report',NULL,0),('Module Def','Website','Website','Name : Website',NULL,0),('DocType','Top Bar Item','Top Bar Item','Name : Top Bar Item',NULL,0),('DocType','Website Meta Tag','Website Meta Tag','Name : Website Meta Tag',NULL,0),('DocType','Web Template Field','Web Template Field','Name : Web Template Field',NULL,0),('DocType','Web Page','Web Page','Name : Web Page',NULL,0),('DocType','Help Article','Help Article','Name : Help Article',NULL,0),('DocType','Website Script','Website Script','Name : Website Script',NULL,0);
